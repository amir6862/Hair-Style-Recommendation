import pickle
import numpy as np
from tensorflow.keras.models import load_model

print("Testing model loading and structure...\n")

# Load preprocessing objects
print("1. Loading SVM preprocessing objects...")
svm_preprocessing = pickle.load(open('models/preprocessing_objects.pkl', 'rb'))
print(f"   Keys: {svm_preprocessing.keys()}")
if 'label_encoder' in svm_preprocessing:
    print(f"   Label encoder classes: {svm_preprocessing['label_encoder'].classes_}")
print()

print("2. Loading MLP preprocessing objects...")
mlp_preprocessing = pickle.load(open('models/mlp_preprocessing_objects.pkl', 'rb'))
print(f"   Keys: {mlp_preprocessing.keys()}")
if 'label_encoder' in mlp_preprocessing:
    print(f"   Face shape encoder classes: {mlp_preprocessing['label_encoder'].classes_}")
if 'hairstyle_encoder' in mlp_preprocessing:
    print(f"   Hairstyle encoder classes: {mlp_preprocessing['hairstyle_encoder'].classes_}")
print()

print("3. Loading SVM model...")
svm_model = pickle.load(open('models/svm_face_shape_classifier.pkl', 'rb'))
print(f"   Model type: {type(svm_model)}")
print(f"   Number of features expected: {svm_model.n_features_in_}")
print(f"   Number of classes: {len(svm_model.classes_)}")
print(f"   Classes: {svm_model.classes_}")
print()

print("4. Loading MLP model...")
mlp_model = load_model('models/mlp_hairstyle_recommender.h5')
print(f"   Model type: {type(mlp_model)}")
print(f"   Input shape: {mlp_model.input_shape}")
print(f"   Output shape: {mlp_model.output_shape}")
print()

print("5. Testing with dummy data...")
# Test SVM
dummy_svm_features = np.random.rand(1, 10)
dummy_svm_scaled = svm_preprocessing['scaler'].transform(dummy_svm_features)
svm_prediction = svm_model.predict(dummy_svm_scaled)
print(f"   SVM raw prediction: {svm_prediction}")
print(f"   SVM prediction type: {type(svm_prediction[0])}")

# Test MLP
dummy_mlp_features = np.random.rand(1, 13)
dummy_mlp_scaled = mlp_preprocessing['scaler'].transform(dummy_mlp_features)
mlp_prediction = mlp_model.predict(dummy_mlp_scaled, verbose=0)
print(f"   MLP prediction shape: {mlp_prediction.shape}")
print(f"   MLP prediction values: {mlp_prediction}")
print(f"   MLP argmax: {np.argmax(mlp_prediction)}")
print()

print("All tests completed!")