import os
import base64
import torch
import numpy as np
from flask import Flask, render_template, request, jsonify
from werkzeug.utils import secure_filename
from PIL import Image
from transformers import (
    AutoImageProcessor, 
    AutoModelForImageClassification,
    ViTImageProcessor,
    ViTForImageClassification,
    SegformerImageProcessor,
    SegformerForSemanticSegmentation
)

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

CACHE_DIR = r'E:\amir\web-app\models'
os.makedirs(CACHE_DIR, exist_ok=True)

def load_model(model_name, model_type, cache_name):
    cache_path = os.path.join(CACHE_DIR, cache_name)
    
    try:
        if os.path.exists(cache_path):
            if model_type == 'vit':
                processor = ViTImageProcessor.from_pretrained(cache_path, local_files_only=True)
                model = ViTForImageClassification.from_pretrained(cache_path, local_files_only=True)
            elif model_type == 'segformer':
                processor = SegformerImageProcessor.from_pretrained(cache_path, local_files_only=True)
                model = SegformerForSemanticSegmentation.from_pretrained(cache_path, local_files_only=True)
        else:
            if model_type == 'vit':
                processor = ViTImageProcessor.from_pretrained(model_name)
                model = ViTForImageClassification.from_pretrained(model_name)
            elif model_type == 'segformer':
                processor = SegformerImageProcessor.from_pretrained(model_name)
                model = SegformerForSemanticSegmentation.from_pretrained(model_name)
            
            processor.save_pretrained(cache_path)
            model.save_pretrained(cache_path)
        
        model.eval()
        return processor, model
    except Exception as e:
        print(f"Error loading {cache_name}: {e}")
        return None, None

face_shape_processor, face_shape_model = load_model('metadome/face_shape_classification', 'vit', 'face_shape')
hair_type_processor, hair_type_model = load_model('dima806/hair_type_image_detection', 'vit', 'hair_type')
face_parsing_processor, face_parsing_model = load_model('jonathandinu/face-parsing', 'segformer', 'face_parsing')
age_processor, age_model = load_model('nateraw/vit-age-classifier', 'vit', 'age')
gender_processor, gender_model = load_model('rizvandwiki/gender-classification', 'vit', 'gender')

HAIRSTYLE_RECOMMENDATIONS = {
    'young': {
        'Oval': {
            'straight': [
                {'name': 'Sleek Undercut', 'desc': 'Modern and sharp, perfect for straight hair', 'maintenance': 'Medium'},
                {'name': 'Textured Quiff', 'desc': 'Adds volume and style', 'maintenance': 'Medium'},
                {'name': 'Side Part', 'desc': 'Classic professional look', 'maintenance': 'Low'},
                {'name': 'Slick Back', 'desc': 'Sophisticated and polished', 'maintenance': 'Medium'}
            ],
            'wavy': [
                {'name': 'Textured Crop', 'desc': 'Embraces natural texture', 'maintenance': 'Low'},
                {'name': 'Messy Fringe', 'desc': 'Casual and trendy', 'maintenance': 'Low'},
                {'name': 'Medium Wavy Style', 'desc': 'Natural and effortless', 'maintenance': 'Low'},
                {'name': 'Surf Hair', 'desc': 'Beachy and relaxed', 'maintenance': 'Low'}
            ],
            'curly': [
                {'name': 'Curly Top Fade', 'desc': 'Showcases natural curls', 'maintenance': 'Medium'},
                {'name': 'Natural Curls', 'desc': 'Embrace your texture', 'maintenance': 'Low'},
                {'name': 'Curly Frohawk', 'desc': 'Bold and distinctive', 'maintenance': 'Medium'},
                {'name': 'Defined Curls', 'desc': 'Polished curly look', 'maintenance': 'Medium'}
            ],
            'kinky': [
                {'name': 'High Top Fade', 'desc': 'Classic and bold', 'maintenance': 'Medium'},
                {'name': 'Natural Afro', 'desc': 'Embrace natural texture', 'maintenance': 'High'},
                {'name': 'Tapered Afro', 'desc': 'Shaped and stylish', 'maintenance': 'Medium'},
                {'name': 'Box Fade', 'desc': 'Sharp and geometric', 'maintenance': 'Medium'}
            ],
            'dreadlocks': [
                {'name': 'Free-form Locs', 'desc': 'Natural and unique', 'maintenance': 'Low'},
                {'name': 'Styled Dreadlocks', 'desc': 'Versatile and expressive', 'maintenance': 'Medium'},
                {'name': 'High Locs', 'desc': 'Elevated and striking', 'maintenance': 'Medium'},
                {'name': 'Loc Bun', 'desc': 'Clean and professional', 'maintenance': 'Low'}
            ]
        },
        'Round': {
            'straight': [
                {'name': 'High Fade Pompadour', 'desc': 'Adds height, elongates face', 'maintenance': 'High'},
                {'name': 'Angular Fringe', 'desc': 'Creates sharp definition', 'maintenance': 'Medium'},
                {'name': 'Side Swept Undercut', 'desc': 'Modern and dimensional', 'maintenance': 'Medium'},
                {'name': 'Vertical Quiff', 'desc': 'Height adds length to face', 'maintenance': 'Medium'}
            ],
            'wavy': [
                {'name': 'Textured Crop', 'desc': 'Angular cut adds definition', 'maintenance': 'Low'},
                {'name': 'High Volume Top', 'desc': 'Creates vertical interest', 'maintenance': 'Medium'},
                {'name': 'Side Part with Height', 'desc': 'Balanced proportions', 'maintenance': 'Medium'},
                {'name': 'Brushed Up Style', 'desc': 'Elongates face shape', 'maintenance': 'Medium'}
            ],
            'curly': [
                {'name': 'Curly High Top', 'desc': 'Natural height advantage', 'maintenance': 'Medium'},
                {'name': 'Angular Curls', 'desc': 'Structured curl pattern', 'maintenance': 'Medium'},
                {'name': 'Tapered Sides Curly Top', 'desc': 'Contrast creates length', 'maintenance': 'Medium'},
                {'name': 'Defined Curly Quiff', 'desc': 'Styled for height', 'maintenance': 'High'}
            ],
            'kinky': [
                {'name': 'High Top Fade', 'desc': 'Maximum vertical height', 'maintenance': 'Medium'},
                {'name': 'Shaped Afro', 'desc': 'Strategic height placement', 'maintenance': 'High'},
                {'name': 'Temple Fade', 'desc': 'Clean angular lines', 'maintenance': 'Medium'},
                {'name': 'Box Cut', 'desc': 'Geometric structure', 'maintenance': 'Medium'}
            ],
            'dreadlocks': [
                {'name': 'High Locs', 'desc': 'Upward style adds length', 'maintenance': 'Medium'},
                {'name': 'Loc Hawk', 'desc': 'Central height emphasis', 'maintenance': 'High'},
                {'name': 'Vertical Locs', 'desc': 'Elongating effect', 'maintenance': 'Medium'},
                {'name': 'Top Knot Locs', 'desc': 'Height at crown', 'maintenance': 'Low'}
            ]
        },
        'Square': {
            'straight': [
                {'name': 'Textured Crop', 'desc': 'Softens angular features', 'maintenance': 'Low'},
                {'name': 'Soft Undercut', 'desc': 'Balances strong jawline', 'maintenance': 'Medium'},
                {'name': 'Layered Cut', 'desc': 'Adds movement and softness', 'maintenance': 'Low'},
                {'name': 'Brushed Forward', 'desc': 'Counters angular jaw', 'maintenance': 'Low'}
            ],
            'wavy': [
                {'name': 'Wavy Textured Style', 'desc': 'Natural softness', 'maintenance': 'Low'},
                {'name': 'Medium Wavy Layers', 'desc': 'Balances face shape', 'maintenance': 'Low'},
                {'name': 'Soft Waves', 'desc': 'Gentle and flowing', 'maintenance': 'Low'},
                {'name': 'Side-Swept Waves', 'desc': 'Diagonal movement softens', 'maintenance': 'Medium'}
            ],
            'curly': [
                {'name': 'Soft Curly Style', 'desc': 'Texture softens angles', 'maintenance': 'Low'},
                {'name': 'Rounded Curls', 'desc': 'Circular shape balances', 'maintenance': 'Medium'},
                {'name': 'Loose Curl Pattern', 'desc': 'Gentle volume', 'maintenance': 'Low'},
                {'name': 'Curly Layers', 'desc': 'Dimensional softness', 'maintenance': 'Medium'}
            ],
            'kinky': [
                {'name': 'Rounded Afro', 'desc': 'Circular shape softens', 'maintenance': 'High'},
                {'name': 'Natural Kinky Curls', 'desc': 'Textured softness', 'maintenance': 'Medium'},
                {'name': 'Tapered Natural', 'desc': 'Gradual shape balance', 'maintenance': 'Medium'},
                {'name': 'Soft Fade', 'desc': 'Gentle transitions', 'maintenance': 'Medium'}
            ],
            'dreadlocks': [
                {'name': 'Rounded Loc Style', 'desc': 'Circular silhouette', 'maintenance': 'Medium'},
                {'name': 'Soft Loc Layers', 'desc': 'Textured dimension', 'maintenance': 'Low'},
                {'name': 'Natural Loc Flow', 'desc': 'Organic movement', 'maintenance': 'Low'},
                {'name': 'Loc Bob', 'desc': 'Rounded shape', 'maintenance': 'Low'}
            ]
        },
        'Heart': {
            'straight': [
                {'name': 'Side Part', 'desc': 'Balances wider forehead', 'maintenance': 'Low'},
                {'name': 'Forward Fringe', 'desc': 'Covers forehead width', 'maintenance': 'Low'},
                {'name': 'Layered Medium', 'desc': 'Adds chin-level width', 'maintenance': 'Medium'},
                {'name': 'Diagonal Style', 'desc': 'Creates balance', 'maintenance': 'Medium'}
            ],
            'wavy': [
                {'name': 'Textured Fringe', 'desc': 'Softens forehead', 'maintenance': 'Low'},
                {'name': 'Medium Waves', 'desc': 'Width at chin level', 'maintenance': 'Low'},
                {'name': 'Side-Swept Waves', 'desc': 'Diagonal balance', 'maintenance': 'Medium'},
                {'name': 'Wavy Layers', 'desc': 'Volumized lower face', 'maintenance': 'Medium'}
            ],
            'curly': [
                {'name': 'Curly Fringe', 'desc': 'Natural forehead coverage', 'maintenance': 'Low'},
                {'name': 'Lower Volume Curls', 'desc': 'Chin-level emphasis', 'maintenance': 'Medium'},
                {'name': 'Shaped Curls', 'desc': 'Strategic volume placement', 'maintenance': 'Medium'},
                {'name': 'Curly Layers', 'desc': 'Balanced proportions', 'maintenance': 'Medium'}
            ],
            'kinky': [
                {'name': 'Natural with Bangs', 'desc': 'Forehead coverage', 'maintenance': 'Medium'},
                {'name': 'Lower Volume Afro', 'desc': 'Chin-level width', 'maintenance': 'High'},
                {'name': 'Shaped Natural', 'desc': 'Proportioned styling', 'maintenance': 'High'},
                {'name': 'Tapered with Fringe', 'desc': 'Balanced shape', 'maintenance': 'Medium'}
            ],
            'dreadlocks': [
                {'name': 'Loc Fringe', 'desc': 'Forward style balance', 'maintenance': 'Low'},
                {'name': 'Lower Loc Volume', 'desc': 'Chin-level emphasis', 'maintenance': 'Medium'},
                {'name': 'Layered Locs', 'desc': 'Graduated proportions', 'maintenance': 'Low'},
                {'name': 'Side-Swept Locs', 'desc': 'Diagonal balance', 'maintenance': 'Medium'}
            ]
        },
        'Oblong': {
            'straight': [
                {'name': 'Side Swept Fringe', 'desc': 'Shortens face appearance', 'maintenance': 'Low'},
                {'name': 'Horizontal Layers', 'desc': 'Creates width', 'maintenance': 'Medium'},
                {'name': 'Volume on Sides', 'desc': 'Widens proportions', 'maintenance': 'Medium'},
                {'name': 'Short Sides Medium Top', 'desc': 'Balanced length', 'maintenance': 'Low'}
            ],
            'wavy': [
                {'name': 'Textured Crop', 'desc': 'Adds width reduces length', 'maintenance': 'Low'},
                {'name': 'Wavy Side Volume', 'desc': 'Horizontal emphasis', 'maintenance': 'Low'},
                {'name': 'Fringe with Waves', 'desc': 'Breaks vertical line', 'maintenance': 'Low'},
                {'name': 'Wide Wavy Style', 'desc': 'Proportioned width', 'maintenance': 'Medium'}
            ],
            'curly': [
                {'name': 'Wide Curly Style', 'desc': 'Horizontal volume', 'maintenance': 'Medium'},
                {'name': 'Curly Fringe', 'desc': 'Shortens appearance', 'maintenance': 'Low'},
                {'name': 'Rounded Curls', 'desc': 'Circular shape balance', 'maintenance': 'Medium'},
                {'name': 'Side Volume Curls', 'desc': 'Width emphasis', 'maintenance': 'Medium'}
            ],
            'kinky': [
                {'name': 'Wide Afro', 'desc': 'Horizontal emphasis', 'maintenance': 'High'},
                {'name': 'Flat Top', 'desc': 'Breaks vertical line', 'maintenance': 'Medium'},
                {'name': 'Temple Fade Wide Top', 'desc': 'Proportioned width', 'maintenance': 'Medium'},
                {'name': 'Natural with Fringe', 'desc': 'Shortened appearance', 'maintenance': 'Medium'}
            ],
            'dreadlocks': [
                {'name': 'Wide Loc Style', 'desc': 'Horizontal volume', 'maintenance': 'Medium'},
                {'name': 'Loc Fringe', 'desc': 'Face-shortening effect', 'maintenance': 'Low'},
                {'name': 'Rounded Locs', 'desc': 'Circular silhouette', 'maintenance': 'Medium'},
                {'name': 'Side Volume Locs', 'desc': 'Width at sides', 'maintenance': 'Medium'}
            ]
        },
        'Default': {
            'straight': [
                {'name': 'Classic Cut', 'desc': 'Versatile and timeless', 'maintenance': 'Low'},
                {'name': 'Modern Style', 'desc': 'Contemporary look', 'maintenance': 'Medium'},
                {'name': 'Professional Cut', 'desc': 'Clean and sharp', 'maintenance': 'Low'},
                {'name': 'Textured Style', 'desc': 'Dynamic and interesting', 'maintenance': 'Medium'}
            ],
            'wavy': [
                {'name': 'Natural Waves', 'desc': 'Effortless style', 'maintenance': 'Low'},
                {'name': 'Textured Crop', 'desc': 'Modern and easy', 'maintenance': 'Low'},
                {'name': 'Wavy Layers', 'desc': 'Dimensional look', 'maintenance': 'Medium'},
                {'name': 'Beach Waves', 'desc': 'Casual and cool', 'maintenance': 'Low'}
            ],
            'curly': [
                {'name': 'Natural Curls', 'desc': 'Embrace your texture', 'maintenance': 'Low'},
                {'name': 'Curly Style', 'desc': 'Defined and shaped', 'maintenance': 'Medium'},
                {'name': 'Textured Curls', 'desc': 'Enhanced natural look', 'maintenance': 'Medium'},
                {'name': 'Managed Curls', 'desc': 'Controlled volume', 'maintenance': 'High'}
            ],
            'kinky': [
                {'name': 'Natural Style', 'desc': 'Authentic texture', 'maintenance': 'Medium'},
                {'name': 'Shaped Natural', 'desc': 'Defined form', 'maintenance': 'High'},
                {'name': 'Fade Style', 'desc': 'Clean and modern', 'maintenance': 'Medium'},
                {'name': 'Textured Natural', 'desc': 'Enhanced natural look', 'maintenance': 'High'}
            ],
            'dreadlocks': [
                {'name': 'Natural Locs', 'desc': 'Organic style', 'maintenance': 'Low'},
                {'name': 'Styled Locs', 'desc': 'Intentional look', 'maintenance': 'Medium'},
                {'name': 'Free Locs', 'desc': 'Unrestricted flow', 'maintenance': 'Low'},
                {'name': 'Managed Locs', 'desc': 'Groomed appearance', 'maintenance': 'Medium'}
            ]
        }
    },
    'mature': {
        'Oval': {
            'straight': [
                {'name': 'Classic Side Part', 'desc': 'Timeless professional', 'maintenance': 'Low'},
                {'name': 'Short Professional', 'desc': 'Clean polished look', 'maintenance': 'Low'},
                {'name': 'Slick Back', 'desc': 'Sophisticated refined', 'maintenance': 'Medium'},
                {'name': 'Executive Cut', 'desc': 'Distinguished style', 'maintenance': 'Low'}
            ],
            'wavy': [
                {'name': 'Natural Wave Style', 'desc': 'Elegant texture', 'maintenance': 'Low'},
                {'name': 'Classic Wavy', 'desc': 'Timeless look', 'maintenance': 'Low'},
                {'name': 'Professional Waves', 'desc': 'Polished style', 'maintenance': 'Medium'},
                {'name': 'Short Wavy Cut', 'desc': 'Distinguished look', 'maintenance': 'Low'}
            ],
            'curly': [
                {'name': 'Short Curly Professional', 'desc': 'Managed curls', 'maintenance': 'Medium'},
                {'name': 'Classic Curl Style', 'desc': 'Refined texture', 'maintenance': 'Medium'},
                {'name': 'Polished Curls', 'desc': 'Professional look', 'maintenance': 'High'},
                {'name': 'Executive Curly', 'desc': 'Distinguished style', 'maintenance': 'Medium'}
            ],
            'kinky': [
                {'name': 'Professional Natural', 'desc': 'Refined texture', 'maintenance': 'Medium'},
                {'name': 'Executive Cut', 'desc': 'Distinguished look', 'maintenance': 'Medium'},
                {'name': 'Classic Natural', 'desc': 'Timeless style', 'maintenance': 'High'},
                {'name': 'Polished Natural', 'desc': 'Professional appearance', 'maintenance': 'High'}
            ],
            'dreadlocks': [
                {'name': 'Professional Locs', 'desc': 'Groomed style', 'maintenance': 'Medium'},
                {'name': 'Classic Loc Style', 'desc': 'Timeless look', 'maintenance': 'Low'},
                {'name': 'Executive Locs', 'desc': 'Distinguished appearance', 'maintenance': 'Medium'},
                {'name': 'Neat Loc Style', 'desc': 'Professional polish', 'maintenance': 'Medium'}
            ]
        },
        'Default': {
            'straight': [
                {'name': 'Professional Cut', 'desc': 'Versatile polished', 'maintenance': 'Low'},
                {'name': 'Classic Style', 'desc': 'Timeless elegant', 'maintenance': 'Low'},
                {'name': 'Business Cut', 'desc': 'Sharp professional', 'maintenance': 'Low'},
                {'name': 'Distinguished Look', 'desc': 'Refined style', 'maintenance': 'Medium'}
            ],
            'wavy': [
                {'name': 'Professional Waves', 'desc': 'Elegant texture', 'maintenance': 'Low'},
                {'name': 'Classic Wavy', 'desc': 'Timeless style', 'maintenance': 'Low'},
                {'name': 'Business Waves', 'desc': 'Polished look', 'maintenance': 'Medium'},
                {'name': 'Distinguished Wavy', 'desc': 'Refined appearance', 'maintenance': 'Medium'}
            ],
            'curly': [
                {'name': 'Professional Curls', 'desc': 'Managed texture', 'maintenance': 'Medium'},
                {'name': 'Classic Curly', 'desc': 'Timeless look', 'maintenance': 'Medium'},
                {'name': 'Business Curls', 'desc': 'Polished style', 'maintenance': 'High'},
                {'name': 'Distinguished Curls', 'desc': 'Refined appearance', 'maintenance': 'High'}
            ],
            'kinky': [
                {'name': 'Professional Natural', 'desc': 'Refined texture', 'maintenance': 'Medium'},
                {'name': 'Classic Natural', 'desc': 'Timeless style', 'maintenance': 'High'},
                {'name': 'Business Natural', 'desc': 'Polished look', 'maintenance': 'High'},
                {'name': 'Distinguished Natural', 'desc': 'Refined appearance', 'maintenance': 'High'}
            ],
            'dreadlocks': [
                {'name': 'Professional Locs', 'desc': 'Groomed style', 'maintenance': 'Medium'},
                {'name': 'Classic Locs', 'desc': 'Timeless look', 'maintenance': 'Low'},
                {'name': 'Business Locs', 'desc': 'Polished appearance', 'maintenance': 'Medium'},
                {'name': 'Distinguished Locs', 'desc': 'Refined style', 'maintenance': 'Medium'}
            ]
        }
    }
}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def detect_face_shape(image_path):
    try:
        if face_shape_model is None or face_shape_processor is None:
            return None, 0
            
        image = Image.open(image_path).convert('RGB')
        inputs = face_shape_processor(images=image, return_tensors="pt")
        
        with torch.no_grad():
            outputs = face_shape_model(**inputs)
            probs = torch.nn.functional.softmax(outputs.logits, dim=-1)
            pred_idx = probs.argmax().item()
            confidence = probs[0][pred_idx].item()
        
        if hasattr(face_shape_model.config, 'id2label'):
            face_shape = face_shape_model.config.id2label[pred_idx]
        else:
            shapes = ['Heart', 'Oblong', 'Oval', 'Round', 'Square']
            face_shape = shapes[pred_idx]
        
        return face_shape, confidence
        
    except Exception as e:
        print(f"ERROR: {e}")
        return None, 0

def detect_hair_type(image_path):
    try:
        if hair_type_model is None or hair_type_processor is None:
            return 'straight', 0.5
            
        image = Image.open(image_path).convert('RGB')
        inputs = hair_type_processor(images=image, return_tensors="pt")
        
        with torch.no_grad():
            outputs = hair_type_model(**inputs)
            probs = torch.nn.functional.softmax(outputs.logits, dim=-1)
            pred_idx = probs.argmax().item()
            confidence = probs[0][pred_idx].item()
        
        if hasattr(hair_type_model.config, 'id2label'):
            hair_type = hair_type_model.config.id2label[pred_idx]
        else:
            hair_types = ['curly', 'dreadlocks', 'kinky', 'straight', 'wavy']
            hair_type = hair_types[pred_idx]
        
        return hair_type.lower(), confidence
    except:
        return 'straight', 0.5

def detect_hair_segmentation(image_path):
    try:
        if face_parsing_model is None or face_parsing_processor is None:
            return False, None
            
        image = Image.open(image_path).convert('RGB')
        inputs = face_parsing_processor(images=image, return_tensors="pt")
        
        with torch.no_grad():
            outputs = face_parsing_model(**inputs)
        
        seg = outputs.logits[0].argmax(dim=0).cpu().numpy()
        unique_labels = np.unique(seg)
        has_hair = len(unique_labels) > 2
        
        return has_hair, seg
    except:
        return False, None

def detect_age(image_path):
    try:
        if age_model is None or age_processor is None:
            return 25
            
        image = Image.open(image_path).convert('RGB')
        inputs = age_processor(images=image, return_tensors="pt")
        
        with torch.no_grad():
            outputs = age_model(**inputs)
            probs = torch.nn.functional.softmax(outputs.logits, dim=-1)
            pred_idx = probs.argmax().item()
        
        age_ranges = ['0-2', '3-9', '10-19', '20-29', '30-39', '40-49', '50-59', '60-69', 'more than 70']
        age_range = age_ranges[pred_idx] if pred_idx < len(age_ranges) else '25-35'
        
        if '-' in age_range:
            ages = age_range.split('-')
            age = (int(ages[0]) + int(ages[1])) // 2
        elif 'more' in age_range:
            age = 75
        else:
            age = 25
        
        return age
    except:
        return 25

def detect_gender(image_path):
    try:
        if gender_model is None or gender_processor is None:
            return 'Man'
            
        image = Image.open(image_path).convert('RGB')
        inputs = gender_processor(images=image, return_tensors="pt")
        
        with torch.no_grad():
            outputs = gender_model(**inputs)
            probs = torch.nn.functional.softmax(outputs.logits, dim=-1)
            pred_idx = probs.argmax().item()
        
        if hasattr(gender_model.config, 'id2label'):
            gender = gender_model.config.id2label[pred_idx]
        else:
            gender = 'Male' if pred_idx == 1 else 'Female'
        
        gender = gender.lower()
        if 'male' in gender and 'fe' not in gender:
            gender = 'Man'
        elif 'female' in gender or 'woman' in gender:
            gender = 'Woman'
        else:
            gender = 'Man'
        
        return gender
    except:
        return 'Man'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400
    
    file = request.files['file']
    
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    if not allowed_file(file.filename):
        return jsonify({'error': 'Invalid file type'}), 400
    
    filepath = None
    img_data = None
    
    try:
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        face_shape, shape_confidence = detect_face_shape(filepath)
        if face_shape is None:
            return jsonify({'error': 'Could not detect face'}), 400
        
        hair_type, hair_confidence = detect_hair_type(filepath)
        has_hair, _ = detect_hair_segmentation(filepath)
        age = detect_age(filepath)
        gender = detect_gender(filepath)
        age_category = 'young' if age < 40 else 'mature'
        
        face_recommendations = HAIRSTYLE_RECOMMENDATIONS[age_category].get(
            face_shape, HAIRSTYLE_RECOMMENDATIONS[age_category]['Default']
        )
        
        hairstyles = face_recommendations.get(
            hair_type, face_recommendations.get('straight', face_recommendations['straight'])
        )
        
        recommended = hairstyles[0]
        alternatives = hairstyles[1:4]
        overall_confidence = (shape_confidence * 0.5 + hair_confidence * 0.5) * 100
        
        with open(filepath, 'rb') as img_file:
            img_data = base64.b64encode(img_file.read()).decode('utf-8')
        
        try:
            os.remove(filepath)
        except:
            pass
        
        return jsonify({
            'success': True,
            'face_shape': face_shape,
            'shape_confidence': float(shape_confidence * 100),
            'hair_type': hair_type,
            'hair_confidence': float(hair_confidence * 100),
            'hair_detected': has_hair,
            'age': int(age),
            'age_category': age_category,
            'gender': gender,
            'recommended_hairstyle': recommended['name'],
            'recommended_description': recommended['desc'],
            'recommended_maintenance': recommended['maintenance'],
            'overall_confidence': float(overall_confidence),
            'alternatives': [alt['name'] for alt in alternatives],
            'alternatives_full': alternatives,
            'image': img_data
        })
        
    except Exception as e:
        if filepath:
            try:
                os.remove(filepath)
            except:
                pass
        print(f"ERROR: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/health')
def health():
    return jsonify({
        'status': 'healthy',
        'models_loaded': {
            'face_shape': face_shape_model is not None,
            'hair_type': hair_type_model is not None,
            'face_parsing': face_parsing_model is not None,
            'age': age_model is not None,
            'gender': gender_model is not None
        }
    })

if __name__ == '__main__':
    print("\nModel Status:")
    print(f"Face Shape: {'LOADED' if face_shape_model else 'FAILED'}")
    print(f"Hair Type: {'LOADED' if hair_type_model else 'FAILED'}")
    print(f"Face Parsing: {'LOADED' if face_parsing_model else 'FAILED'}")
    print(f"Age: {'LOADED' if age_model else 'FAILED'}")
    print(f"Gender: {'LOADED' if gender_model else 'FAILED'}\n")
    
    app.run(debug=True, host='0.0.0.0', port=5000)